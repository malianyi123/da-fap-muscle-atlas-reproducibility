# Computational Perturbation-Guided DA-FAP Atlas

Provisional title:

**Computational perturbation-guided single-cell and spatial atlas reveals degeneration-associated fibro-adipogenic progenitor programs in skeletal muscle**

This repository is organized for a pure public-data computational biology project focused on skeletal muscle degeneration, aging, sarcopenia, fibrosis, fatty infiltration, regeneration failure, and fibro-adipogenic progenitor-like stromal states.

Current status: **Phase 0-15 plus manuscript-facing figures and draft implemented**. The repository scaffold, dataset inventory, selected public-data download, metadata standardization, human QC/integration, major cell-type annotation, FAP-focused downstream analysis, GRN-regression virtual knockdown, cross-species spatial support, multi-cohort bulk meta-validation, sensitivity analyses, publication figure assembly, supplementary table assembly, and manuscript draft are in place.

## Project Layout

- `config/config.yaml`: project paths, analysis defaults, search terms, and gene modules.
- `environment/environment.yml`: Python-first environment with Scanpy/scVI/CellOracle and R support.
- `environment/sessionInfo.txt`: local runtime note and R/Python version record for Phase 0.
- `data/metadata/manual_dataset_seed.csv`: curated Phase 1 dataset candidates.
- `data/metadata/dataset_metadata.csv`: validated dataset inventory generated from the seed file.
- `data/metadata/dataset_inventory_summary.md`: Phase 1 readiness summary.
- `scripts/01_data_search/build_dataset_inventory.py`: validates and summarizes curated records.
- `scripts/01_data_search/search_public_datasets.py`: lightweight NCBI/GEO discovery helper.
- `scripts/04_fap_subclustering/fap_focused_analysis.py`: FAP subclustering, DA-FAP scoring, trajectory, communication, and initial regulator workflow.
- `scripts/09_spatial_validation/spatial_validation_gse225766.py`: mouse Visium spatial signature support workflow.
- `scripts/10_bulk_validation/bulk_validation_gse164471.py`: first human bulk aging validation workflow.
- `scripts/10_bulk_validation/bulk_multi_cohort_meta_validation.py`: multi-cohort human bulk validation and random-effects meta-analysis.
- `scripts/12_figure_generation/build_publication_figures.py`: manuscript-facing Figure 1-9 assembly.
- `scripts/13_manuscript/assemble_supplementary_tables.py`: stable Supplementary Table 1-16 assembly.
- `scripts/15_quality_control/sensitivity_analysis.py`: leave-one-dataset-out, module-gene, artifact, and integration sensitivity analysis.

## Reproduce Phase 0-1

From the project root:

```bash
python3 scripts/00_setup/check_project_structure.py
python3 scripts/01_data_search/build_dataset_inventory.py
python3 scripts/01_data_search/search_public_datasets.py
```

The first two commands do not download data. The discovery helper queries NCBI E-utilities and writes a compact search log to `data/metadata/ncbi_geo_search_results.csv`.

## Reproduce Phase 2-3

The runnable Phase 2-3 pass uses a local `.venv`. To recreate it from scratch:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install scanpy anndata h5py openpyxl pyarrow matplotlib seaborn pyyaml requests tqdm harmonypy scrublet leidenalg igraph scikit-misc
```

Then run:

```bash
.venv/bin/python scripts/02_download/download_phase2_datasets.py
.venv/bin/python scripts/02_download/standardize_single_cell_objects.py
.venv/bin/python scripts/03_sc_qc_integration/qc_integrate_annotate.py
```

Current Phase 2-3 outputs:

- `data/metadata/phase2_download_manifest.csv`
- `data/metadata/phase2_standardized_single_cell_manifest.csv`
- `results/objects/phase2_standardized/*.h5ad`
- `results/objects/phase3_human_integrated_initial.h5ad`
- `data/processed/phase3_human_integrated_metadata.csv.gz`
- `results/tables/phase3_qc_summary.csv`
- `results/tables/phase3_cell_type_composition.csv`
- `results/tables/phase3_marker_score_summary.csv`
- `results/figures/phase3_umap_by_dataset.{png,pdf}`
- `results/figures/phase3_umap_by_major_cell_type.{png,pdf}`
- `results/figures/phase3_umap_by_leiden.{png,pdf}`
- `results/figures/phase3_cell_type_composition_by_dataset.{png,pdf}`

For this first executable pass, the CELLxGENE all-cells H5AD was left as an optional large download because the public endpoint was slow. The smaller human aging atlas immune and fibroblast/Schwann compartments were loaded, and GSE167186, GSE143704, and GSE130646 were standardized and integrated. Mouse GSE138826 was downloaded but deferred because its public matrix is a large whitespace-delimited expression table without companion cell metadata in the downloaded file and should be converted separately for mouse-only support analysis.

## Reproduce Phase 4-10 and Manuscript Outputs

After Phase 2-3 objects exist, run:

```bash
.venv/bin/python scripts/04_fap_subclustering/fap_focused_analysis.py
.venv/bin/python scripts/08_virtual_knockout/grn_regression_virtual_knockout.py
.venv/bin/python scripts/09_spatial_validation/spatial_validation_gse225766.py
.venv/bin/python scripts/10_bulk_validation/bulk_validation_gse164471.py
.venv/bin/python scripts/10_bulk_validation/bulk_multi_cohort_meta_validation.py
.venv/bin/python scripts/15_quality_control/sensitivity_analysis.py
.venv/bin/python scripts/12_figure_generation/build_publication_figures.py
.venv/bin/python scripts/13_manuscript/assemble_supplementary_tables.py
```

Key downstream outputs:

- `results/objects/phase4_fap_integrated.h5ad`
- `results/objects/phase9_spatial_gse225766_scores.h5ad`
- `data/processed/bulk_validation/GSE164471/GSE164471_logCPM_gene_symbol.csv.gz`
- `results/figures/figure1_study_design_dataset_map.{png,pdf,svg}`
- `results/figures/figure2_integrated_single_cell_atlas.{png,pdf,svg}`
- `results/figures/figure3_fap_subclustering_da_fap_definition.{png,pdf,svg}`
- `results/figures/figure4_trajectory_cell_communication.{png,pdf,svg}`
- `results/figures/figure5_regulatory_network_virtual_knockout.{png,pdf,svg}`
- `results/figures/figure6_spatial_da_fap_niche_support.{png,pdf,svg}`
- `results/figures/figure7_bulk_validation.{png,pdf,svg}`
- `results/figures/figure8_mechanistic_model.{png,pdf,svg}`
- `results/figures/figure9_sensitivity_analysis.{png,pdf,svg}`
- `results/tables/supplementary_table_*.csv`
- `manuscript/main_text.md`
- `manuscript/abstract.md`
- `manuscript/figure_legends.md`
- `manuscript/supplementary_methods.md`
- `manuscript/chinese_summary.md`

The Phase 8 perturbation workflow now includes GRN-regression virtual knockdown. It nominates candidate perturbation-sensitive nodes but should not be described as experimental causality or a definitive motif-constrained CellOracle/scTenifoldKnk result.

## Environment

Create the conda environment:

```bash
conda env create -f environment/environment.yml
conda activate da-fap-atlas
```

Some packages, especially CellChat and scTenifoldKnk, may require installation through R after the conda environment is active. Those are intentionally kept as supplemental analyses because the primary workflow is Python/Scanpy/scVI/CellOracle.

## Phase Gate and Interpretation Guardrails

The current Phase 1 inventory satisfies the minimum discovery gate:

- usable scRNA-seq/snRNA-seq candidate: human skeletal muscle aging atlas and GSE167186;
- usable external bulk validation candidates: GSE164471, GSE111017, GSE25941, GSE38718;
- usable spatial transcriptomics candidate: GSE225766, with GSE215305/GSE210773 as secondary spatial candidates.

Spatial evidence is currently strongest in mouse dystrophic/regeneration contexts rather than human aging muscle, so the manuscript must avoid claiming definitive human spatial validation unless a suitable human spatial dataset is later confirmed.

All DA-FAP labels should be interpreted as a degeneration-associated FAP-like state, not a new cell type. Computational perturbation results are candidate predictions and require experimental validation.
